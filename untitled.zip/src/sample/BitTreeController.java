package sample;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * @author T.Whiter
 * @Date 2020/2/21 12:14
 * @Version 1.0
 */
public class BitTreeController implements Initializable {




    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
