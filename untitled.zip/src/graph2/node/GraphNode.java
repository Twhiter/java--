package graph2.node;

/**
 * @author T.Whiter
 * @Date 2020/2/19 15:09
 * @Version 1.0
 */
public class GraphNode extends Node {
    public GraphNode(int ID) {
        super(ID);
    }
}
