package graph2.node;

import java.util.ArrayList;
import java.util.List;

/**
 * @author T.Whiter
 * @Date 2020/2/19 13:53
 * @Version 1.0
 */
public class BitTreeNode extends AbstractTreeNode {
    private BitTreeNode left = null;
    private BitTreeNode right = null;
    private BitTreeNode parent = null;

    public BitTreeNode(int ID) {
        super(ID);
    }

    @Override
    public List<AbstractTreeNode> getChildren() {
        ArrayList<AbstractTreeNode> children = new ArrayList<>();
        children.add(left);
        children.add(right);
        return children;
    }

    @Override
    public AbstractTreeNode getParent() {
        return parent;
    }

    public void setParent(BitTreeNode parent) {
        this.parent = parent;
    }

    public void setLeft(BitTreeNode left) {
        this.left = left;
    }

    public void setRight(BitTreeNode right) {
        this.right = right;
    }

    public BitTreeNode left(){
        return left;
    }

    public BitTreeNode right() {
        return right;
    }


}
