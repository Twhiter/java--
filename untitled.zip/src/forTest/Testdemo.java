package forTest;

import graph2.graph.Edge;
import graph2.graph.Graph;
import graph2.node.BitTreeNode;
import graph2.node.GraphNode;
import graph2.tree.BitTree;
import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Scanner;


/**
 * @author T.Whiter
 * @Date 2020/2/17 9:22
 * @Version 1.0
 */
public class Testdemo extends Application implements Serializable {
    public static void main(String[] args) throws IOException {
        System.out.println("123".hashCode());
        System.out.println("123".hashCode());
        System.out.println("123".hashCode());
        System.out.println("123".hashCode());
        System.out.println("123".hashCode());
    }

    public static void BitTreeTest() throws IOException {
        ArrayList<BitTreeNode> nodes = new ArrayList<>();

        for (int i = 0; i < 6; i++) {
            nodes.add(new BitTreeNode(i));
        }

        FileOutputStream fileOutputStream = new FileOutputStream("out.txt");
        PrintStream printStream = new PrintStream(fileOutputStream);
        System.setOut(printStream);


        BitTree bitTree = BitTree.getInstance(nodes);

        System.out.println("Pre------------------------");
        for (var v : bitTree.preOrderVisit()) {
            System.out.println(v.getID());
        }

        System.out.println("in------------------------");
        for (var v : bitTree.inOrderVisit()) {
            System.out.println(v.getID());
        }

        System.out.println("post------------------------");
        for (var v : bitTree.postOrderVisit()) {
            System.out.println(v.getID());
        }

        fileOutputStream.close();
        printStream.close();
        System.out.close();


    }

    public static void graphTest() throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream("out.txt");
        FileInputStream fileInputStream = new FileInputStream("in.txt");
        PrintStream printStream = new PrintStream(fileOutputStream);

        System.setOut(printStream);
        ArrayList<Edge> list = new ArrayList<>();

        Scanner in = new Scanner(fileInputStream);

        Hashtable<Integer,GraphNode> hashtable = new Hashtable<>();

        while (true) {
            int fromID = in.nextInt();
            int toID = in.nextInt();
            double weight = in.nextDouble();

            if (fromID == -1|| toID == -1 || weight < 0)
                break;

            GraphNode from ;
            if (hashtable.containsKey(fromID))
                from = hashtable.get(fromID);
            else {
                from  = new GraphNode(fromID);
                hashtable.put(fromID,from);
            }

            GraphNode to;
            if (hashtable.containsKey(toID))
                to = hashtable.get(toID);
            else {
                to  = new GraphNode(toID);
                hashtable.put(toID,to);
            }



            Edge edge = new Edge(from,to,weight);

            list.add(edge);
        }

        Graph graph = Graph.getInstance(list);

//        ArrayList<GraphNode> bfs = new ArrayList<>();
//        ArrayList<GraphNode> dfs = new ArrayList<>();
//        ArrayList<Edge> shortestPath = new ArrayList<>();


        System.out.println("BFS-------------------");

        for (var node : graph.bfs()) {
            System.out.println(node.getID());
        }

        System.out.println("DFS-------------------");
        for (var node : graph.bfs()) {
            System.out.println(node.getID());
        }


        System.out.println("shortestPath");
        for (var edge : graph.shortestPath()) {
            System.out.println(edge);
        }


        System.out.close();
        fileInputStream.close();
        fileOutputStream.close();
        printStream.close();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {


        AnchorPane anchorPane = new AnchorPane();


        Rectangle rect = new Rectangle (100, 40, 100, 100);
        rect.setArcHeight(50);
        rect.setArcWidth(50);

        FadeTransition ft = new FadeTransition(Duration.millis(3000), rect);
        ft.setFromValue(1.0);
        ft.setToValue(0.3);
        ft.setCycleCount(4);
        ft.setAutoReverse(true);

        anchorPane.getChildren().add(rect);

        ft.play();


        Scene scene = new Scene(anchorPane);
        primaryStage.setScene(scene);
        primaryStage.show();



    }
}
