package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.util.Duration;
import tool.Tool;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * @author T.Whiter
 * @Date 2020/2/20 16:59
 * @Version 1.0
 */
public class QueueController implements Initializable {

    @FXML
    private HBox hBox;

    @FXML
    private Button pop,push;

    @FXML
    private ScrollBar scrollBar;

    @FXML
    private TextField input;



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        scrollBar.setUnitIncrement(50);
        scrollBar.maxProperty().bind(hBox.widthProperty());

        scrollBar.valueProperty().addListener((observable, oldValue, newValue) ->
                hBox.setLayoutX(-newValue.doubleValue()));
    }


    @FXML
    public void push() {
        String content = input.getText();
        input.clear();
        TextField textField = Tool.initializeNode(36,content);
        textField.setMaxSize(105,85);
        textField.setMinSize(105,85);

        KeyFrame keyFrame = Tool.setNodeAppear(Duration.seconds(0.75),textField);
        Timeline timeline = new Timeline(keyFrame);

        timeline.play();
        hBox.getChildren().add(textField);
    }

    @FXML
    public void pop() {
        if (hBox.getChildren().size() == 0)
            return;
        Node node = hBox.getChildren().get(0);

        KeyFrame keyFrame = Tool.setNodeDisappear(Duration.seconds(0.75),node);
        Timeline timeline = new Timeline(keyFrame);
        timeline.setOnFinished(event -> hBox.getChildren().remove(0));

        timeline.play();
    }

}
