package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import tool.Tool;

import java.io.IOException;
import java.net.URL;
import java.util.Hashtable;
import java.util.ResourceBundle;

import static tool.Tool.setNodeAppear;
import static tool.Tool.setNodeDisappear;

/**
 * @author T.Whiter
 * @Date 2020/2/21 11:21
 * @Version 1.0
 */
public class MainController implements Initializable {


    @FXML
    private AnchorPane anchorPane;


    @FXML
    private ComboBox<String> modeChoose;

    @FXML
    private MenuItem fileSave,fileOpen;

    private final String[] modes = {"stack","queue","bitTree","graph"};

    private Hashtable<String, Node> subPanes;

    private Node currentPane = new Pane();





    private void init() throws IOException {
       subPanes =  new Hashtable<>();
        for (String mode : modes) {
            Node node = FXMLLoader.load(getClass().getResource(mode + "Sample.fxml"));
            subPanes.put(mode, node);
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            init();
        } catch (IOException e) {
            e.printStackTrace();
        }

        modeChoose.getItems().addAll(modes);
        modeChoose.valueProperty().addListener((observable, oldValue, newValue) -> {

            Timeline timeline = new Timeline(setNodeDisappear(Duration.seconds(0.5),currentPane));

            timeline.setOnFinished(event -> {
                anchorPane.getChildren().remove(currentPane);

                currentPane = subPanes.get(newValue);

                anchorPane.getChildren().add(currentPane);
                AnchorPane.setLeftAnchor(currentPane,100.0);
                AnchorPane.setTopAnchor(currentPane,100.0);

                Timeline timeline1 = new Timeline(setNodeAppear(Duration.seconds(0.5),currentPane));
                timeline1.play();
            });

            timeline.play();
        });

        modeChoose.setValue(modes[0]);
    }
}
