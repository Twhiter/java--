package sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableView;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * @author T.Whiter
 * @Date 2020/2/21 8:08
 * @Version 1.0
 */
public class GraphController implements Initializable {

    @FXML
    private Button add,delete;

    @FXML
    private TableView inputTable;

    private Button openFile = new Button("打开文件");





    @Override
    public void initialize(URL location, ResourceBundle resources) {

        inputTable.setTableMenuButtonVisible(true);
        inputTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        inputTable.setPlaceholder(openFile);
    }
}
