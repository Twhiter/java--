package sample;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.util.Duration;
import tool.Tool;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * @author T.Whiter
 * @Date 2020/2/20 11:12
 * @Version 1.0
 */
public class StackController implements Initializable {
    @FXML
    private Button push,pop;

    @FXML
    private TextField input;

    @FXML
    private VBox vBox;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private ScrollBar scrollBar;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        scrollBar.setUnitIncrement(50);
        scrollBar.maxProperty().bind(vBox.heightProperty());
        scrollBar.valueProperty().addListener((observable, oldValue, newValue) ->
                vBox.setLayoutY(-newValue.doubleValue()));
    }


    @FXML
    public void push() {
        String content = input.getText();
        input.clear();

        TextField textField = Tool.initializeNode(41,content);

        KeyFrame keyFrame = Tool.setNodeAppear(Duration.seconds(0.75),textField);

        Timeline timeline = new Timeline(keyFrame);


        VBox vBox2 = new VBox();
        vBox2.getChildren().addAll(vBox.getChildren());

        vBox.getChildren().clear();
        vBox.getChildren().add(textField);
        vBox.getChildren().addAll(vBox2.getChildren());
        timeline.play();

    }

    @FXML
    public void pop() {
        try {

            KeyFrame keyFrame = Tool.setNodeDisappear(Duration.seconds(0.75),vBox.getChildren().get(0));

            Timeline timeline = new Timeline(keyFrame);
            timeline.setOnFinished(event -> vBox.getChildren().remove(0));

            timeline.play();
        }
        catch (NullPointerException ignored){}
    }
}
