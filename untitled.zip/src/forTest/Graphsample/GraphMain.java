package forTest.Graphsample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class GraphMain extends Application {


    public static void main(String[] args) {
        launch(args);
    }




    @Override
    public void start(Stage primaryStage) throws Exception {

        Parent parent = FXMLLoader.load(getClass().getResource("../sample/graphSample.fxml"));
//
//        AnchorPane anchorPane = new AnchorPane();
////
//        Person person1 = new Person("蔡","连发");
//        Person person2 = new Person("熊","佳金");
//        Person person33 = new Person("葛","宇聪");
//
//
//        ObservableList<Person> list = FXCollections.observableArrayList(person1,person2,person33);
//
//
//        TableView<Person> tableView = new TableView<>(list);
//
//        TableColumn<Person,String> firstColumn = new TableColumn<>("姓");
//        firstColumn.setCellValueFactory(param -> param.getValue().firstNameProperty());
//
//        TableColumn<Person,String> secondColumn = new TableColumn<>("名");
//        secondColumn.setCellValueFactory(param -> param.getValue().lastNameProperty());
//
//        tableView.getColumns().setAll(firstColumn,secondColumn);
//
//        tableView.setEditable(true);
//
//        firstColumn.setCellFactory(TextFieldTableCell.forTableColumn());
//        secondColumn.setCellFactory(TextFieldTableCell.forTableColumn());
//
//
//        Button button = new Button("1233333333333");
//
//
//        button.setOnMouseClicked(event -> {
//            ObservableList<Person> deleteList = tableView.getSelectionModel().getSelectedItems();
//
//
//            list.removeAll(deleteList);
//
//        });
//
//        tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//        tableView.setTableMenuButtonVisible(true);
//
//
//
//        anchorPane.getChildren().addAll(button);
//        AnchorPane.setLeftAnchor(button,400.0);
//
//        AnchorPane.setTopAnchor(button,200.0);
//
//
//
//
//
//
//
//        anchorPane.getChildren().add(tableView);

        Scene scene = new Scene(parent);

        primaryStage.setScene(scene);
        primaryStage.show();






    }
}
